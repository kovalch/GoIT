def cleanup_start():
    print("Start to cleanup directory")